/* Needed to wrap the user program in an object file. Don't remove. */
